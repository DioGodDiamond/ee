/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package todolist;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleListProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 *
 * @author vally
 */
public class FXMLDocumentController implements Initializable {
    private ObservableList<Evento> list;
    private SimpleListProperty<Evento> listasimple;

    @FXML
    private Button agg;
    @FXML
    private DatePicker date;
    @FXML
    private TextField descr_tf;
    @FXML
    private TableView<Evento> tab;
    @FXML
    private TableColumn<Evento, LocalDate> data_col;
    @FXML
    private TableColumn<Evento, String> event_col;
    @FXML
    private MenuItem del_menu;
    @FXML
    private MenuItem imp_menu;
    @FXML
    private MenuItem exp_menu;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        list=FXCollections.observableArrayList();
        listasimple= new SimpleListProperty();
        
        
        date.setValue(LocalDate.now());
        
        
        agg.disableProperty().bind(descr_tf.textProperty().isEmpty());
        exp_menu.disableProperty().bind(listasimple.emptyProperty());
        del_menu.disableProperty().bind(listasimple.emptyProperty());
        imp_menu.disableProperty().bind(listasimple.emptyProperty().not());
        
        data_col.setCellValueFactory(new PropertyValueFactory("data"));
        event_col.setCellValueFactory(new PropertyValueFactory("descrizione"));
        
        event_col.setCellFactory(TextFieldTableCell.forTableColumn());
        
        tab.setItems(list);
        listasimple.setValue(list);
        Thread t = new Thread(new TimedSaving(list));
        t.start();
        
    }    
    
    @FXML
    private void aggiungiEvento(ActionEvent event) {
        Evento a =  new Evento(date.getValue(), descr_tf.getText());
        if(list.isEmpty()){
            list.add(a);
        }else{
        for(int i =0; i<list.size();i++){
            if(a.compareTo(list.get(i))<0){
                list.add(i, a);
                break;
            }else if (i==list.size()-1){
                list.add(a);
                break;
            }
        }
        }
        
        descr_tf.clear();
    }
    
    @FXML
    private void delete_event(ActionEvent event) {
        list.remove(tab.getSelectionModel().getSelectedItem());
    }

    @FXML
    private void Import(ActionEvent event) {
        try(Scanner o = new Scanner(new BufferedReader(new FileReader("ListaEventi.txt")))){
            while(o.hasNext()){
                String e1 = o.nextLine();
                String [] e2 = e1.split(";");
                list.add(new Evento(LocalDate.parse(e2[0]), e2[1]));
            }
        } catch (FileNotFoundException ex) {ex.printStackTrace();}
        
    }

    @FXML
    private void export(ActionEvent event) {
        try(PrintWriter o = new PrintWriter(new BufferedWriter(new FileWriter("ListaEventi.txt")))){
            for(Evento s : list){
                o.print(s.getData().toString());
                o.print(";");
               String s1 = s.getDescrizione().replace(';', '|');
                o.print(s1 + "\n");
            }
        }   catch (IOException ex) {ex.printStackTrace();}
        
    }


    
}
