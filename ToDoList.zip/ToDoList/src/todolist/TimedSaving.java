/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package todolist;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;

/**
 *
 * @author vally
 */
public class TimedSaving implements Runnable{
    private ObservableList<Evento> list;

    public TimedSaving(ObservableList<Evento> list) {
        this.list = list;
    }
    
    

    @Override
    public void run() {
        while(true){
            
            try(ObjectOutputStream o = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("ListaEventi.txt")))){
            List<Evento> lista = new LinkedList<Evento>(list);
            o.writeObject(lista);
           
        }   catch (FileNotFoundException ex) {
                Logger.getLogger(TimedSaving.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(TimedSaving.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                Thread.sleep(10000);
            } catch (InterruptedException ex) {
                Logger.getLogger(TimedSaving.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}
