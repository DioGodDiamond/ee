/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package todolist;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

/**
 *
 * @author vally
 */
public class Evento implements Comparable, Serializable{
    private LocalDate data;
    private String descrizione;
    private int ID=0;

    public Evento(LocalDate data, String descrizione) {
        this.ID=ID++;
        this.data = data;
        this.descrizione = descrizione;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public LocalDate getData() {
        return data;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public int getID() {
        return ID;
    }
    

    @Override
    public int compareTo(Object o) {
        if(o==null){
            System.err.println("L'oggetto passato non esiste.");
            return 0;
        }
        Evento n = (Evento) o;
        if(this.data.isEqual(n.getData())){
            if(this.ID==n.getID()){
                return 0;
            }else if(this.ID>n.getID()){
                return 1;
            }else{
                return -1;
            }
        }else if(this.data.isBefore(n.getData())){
            return -1;
        }else {
            return 1;
        }
    }
    
    
    
    
}
