/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package stackpanepass;

import com.sun.javafx.css.converters.StringConverter;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Array;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.AnchorPane;
import javafx.util.converter.IntegerStringConverter;

/**
 *
 * @author vally
 */
public class FXMLDocumentController implements Initializable {
    private ObservableList<Contact> list;
    private GenerateOTP g = new GenerateOTP();
    private Clipboard c = Clipboard.getSystemClipboard();

    @FXML
    private TextField nome_tf;
    @FXML
    private TextField cognome_tf;
    @FXML
    private TextField num_tf;
    @FXML
    private TableView<Contact> tab;
    @FXML
    private TableColumn<Contact, String> nome_col;
    @FXML
    private TableColumn<Contact, String> cogn_col;
    @FXML
    private TableColumn<Contact, Integer> num_col;
    @FXML
    private TextField unlock_tf;
    @FXML
    private Button unlock_but;
    @FXML
    private Label err_lab;
    @FXML
    private AnchorPane tab_pane;
    @FXML
    private AnchorPane lock_pane;
    @FXML
    private Button addContact_butt;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        list = FXCollections.observableArrayList();
        Thread t  = new Thread(g);
        t.start();
        
        BooleanBinding b1 = Bindings.or(nome_tf.textProperty().isEmpty(), Bindings.or(cognome_tf.textProperty().isEmpty(), num_tf.textProperty().isEmpty()));
        
        addContact_butt.disableProperty().bind(b1);
                
        unlock_but.disableProperty().bind(unlock_tf.textProperty().isEmpty());
        
        nome_col.setCellValueFactory(new PropertyValueFactory("nome"));
        cogn_col.setCellValueFactory(new PropertyValueFactory("cognome"));
        num_col.setCellValueFactory(new PropertyValueFactory("numeroo"));
        
        nome_col.setCellFactory(TextFieldTableCell.forTableColumn());
        cogn_col.setCellFactory(TextFieldTableCell.forTableColumn());
        num_col.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
        
        try(ObjectInputStream o = new ObjectInputStream(new BufferedInputStream(new FileInputStream("saved.bin")))){
            List<Contact> contatti=  (List<Contact>) o.readObject();
            list = FXCollections.observableArrayList(contatti);
        } catch (IOException ex) {ex.printStackTrace();} 
        catch (ClassNotFoundException ex) {ex.printStackTrace();}
        
        tab.setItems(list);
        
        }

    //private void addContact(ActionEvent event) {
        
    //}

    @FXML
    private void unlock(ActionEvent event) {
        /*if(Integer.parseInt(unlock_tf.getText())==g.getN()){
            lock_pane.setVisible(false);
            tab_pane.setVisible(true);                                              PARTE DA DECOMMENTARE
        }else{
            err_lab.setVisible(true);
        }*/
        
        lock_pane.setVisible(false);
            tab_pane.setVisible(true);                              //DA CANCELLARE
        
    }

    @FXML
    private void rimuovi(ActionEvent event) {
        list.remove(tab.getSelectionModel().getSelectedItem());
    }

    @FXML
    private void copia(ActionEvent event) {
        Contact con = tab.getSelectionModel().getSelectedItem();
        ClipboardContent elem = new ClipboardContent();
        elem.putString(con.getNome()+ ";"+con.getCognome()+";"+con.getNumeroo().toString()+";");
        c.setContent(elem);
    }
    @FXML
    private void modNome(TableColumn.CellEditEvent<Contact, String> event) {
        Contact c = tab.getSelectionModel().getSelectedItem();
        if(list.contains(new Contact(event.getNewValue(), c.getCognome(), c.getNumeroo()))){
            Alert a = new Alert(Alert.AlertType.ERROR);
                    a.setTitle("Errore");
                    a.setContentText("Contatto già presente");
                    a.setHeaderText("Errore");
                    a.showAndWait();
        }else{
            c.setNome(event.getNewValue());
        }
    }
    @FXML
    private void modCognome(TableColumn.CellEditEvent<Contact, String> event) {
        Contact c = tab.getSelectionModel().getSelectedItem();
        if(list.contains(new Contact(c.getNome(), event.getNewValue(), c.getNumeroo()))){
            Alert a = new Alert(Alert.AlertType.ERROR);
                    a.setTitle("Errore");
                    a.setContentText("Contatto già presente");
                    a.setHeaderText("Errore");
                    a.showAndWait();
        }else{
            c.setCognome(event.getNewValue());
        }
    }
    @FXML
    private void modNum(TableColumn.CellEditEvent<Contact, Integer> event) {
        Contact c = tab.getSelectionModel().getSelectedItem();
        if(list.contains(new Contact(c.getNome(), c.getCognome(), event.getNewValue()))){
            Alert a = new Alert(Alert.AlertType.ERROR);
                    a.setTitle("Errore");
                    a.setContentText("Contatto già presente");
                    a.setHeaderText("Errore");
                    a.showAndWait();
        }else{
            c.setNumeroo(event.getNewValue());
        }
    }

    @FXML
    private void saveFile(ActionEvent event) {
        try(ObjectOutputStream o = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("saved.bin")))){
            List<Contact> contatti = new LinkedList<Contact>(list);
            o.writeObject(contatti);
        } catch (FileNotFoundException ex) {ex.printStackTrace();
        } catch (IOException ex) {ex.printStackTrace();}
        
    }

    @FXML
    private void exit(ActionEvent event) {
        System.exit(0);
    }

    @FXML
    private void addContact1(ActionEvent event) {
        Contact c = new Contact(nome_tf.getText(), cognome_tf.getText(), (int) Integer.parseInt(num_tf.getText()));
            if(list.contains(c)){
                Alert a = new Alert(Alert.AlertType.ERROR);
                    a.setTitle("Errore");
                    a.setContentText("Contatto già presente");
                    a.setHeaderText("Errore");
                    a.showAndWait();
            }else{
                list.add(c);
            }
        System.out.println("ciao");
    }

   

}
