/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stackpanepass;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author vally
 */
public class GenerateOTP implements Runnable{
    private int n;
    
    public GenerateOTP(){
    };

    @Override
    public void run() {
        while(true){
            try(PrintWriter o = new PrintWriter(new BufferedWriter(new FileWriter("otp.txt")))){
                n = (int) Math.round((double)Math.random()*500);
                System.out.println("il codice è" + " " + n);
                o.print("Il codice di sblocco OTP è: " + " " + n);
            } catch (IOException ex) {ex.printStackTrace();} 
            
            try {
                Thread.sleep(10000);
            } catch (InterruptedException ex) {ex.printStackTrace();}
            
        }
    }

    public int getN() {
        return n;
    }
    
    
    
}
