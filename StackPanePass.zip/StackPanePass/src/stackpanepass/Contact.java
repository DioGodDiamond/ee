/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stackpanepass;

import java.io.Serializable;
import java.util.Objects;

/**
 *
 * @author vally
 */
public class Contact implements Serializable{
    private String nome;
    private String cognome;
    private int numeroo;

    public Contact(String nome, String cognome, Integer numeroo) {
        this.nome = nome;
        this.cognome = cognome;
        this.numeroo = numeroo;
    }

    public Integer getNumeroo() {
        return numeroo;
    }

    public void setNumeroo(Integer numeroo) {
        this.numeroo = numeroo;
    }

  

    public String getNome() {
        return nome;
    }

    public String getCognome() {
        return cognome;
    }

    /*public int getNumeroo() {
        return numeroo;
    }*/

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    /*public void setNumeroo(int numeroo) {
        this.numeroo = numeroo;
    }*/

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.nome);
        hash = 97 * hash + Objects.hashCode(this.cognome);
        hash = 97 * hash + Objects.hashCode(this.numeroo);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Contact other = (Contact) obj;
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.cognome, other.cognome)) {
            return false;
        }
        return Objects.equals(this.numeroo, other.numeroo);
    }

   
    
    
    
}
