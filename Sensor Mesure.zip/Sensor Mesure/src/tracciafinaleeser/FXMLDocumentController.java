 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package tracciafinaleeser;

import francescoliguori.hubService;
import francescoliguori.sensorService;
import francescoliguori.sensorMeasure;
import francescoliguori.hubQueue;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

/**
 *
 * @author vally
 */
public class FXMLDocumentController implements Initializable {
        hubQueue q = new hubQueue(3);
        sensorService s1 = new sensorService(q,1);
        sensorService s2 = new sensorService(q, 2);
        hubService h = new hubService(q);
        FileChooser file = new FileChooser();
    
   @FXML private Button bothub;
   @FXML private Button exp;
   @FXML private ProgressIndicator pr1;
   @FXML private ProgressIndicator pr2;
   @FXML private ProgressIndicator pr3;
   @FXML private Button sens1;
   @FXML private Button sens2;
   @FXML private TableView tab;
   @FXML private TableColumn description;    
   @FXML private TableColumn sensorID;
   @FXML private TableColumn time;
   @FXML private TableColumn unit;
   @FXML private TableColumn value;
    @FXML
    private AnchorPane rootPane;
  
   @FXML private void handleButtonAction(ActionEvent event) {
        file.setInitialDirectory(file.getInitialDirectory());
        h.cancel();
        String c = "sdasd";
        File f = file.showSaveDialog(rootPane.getScene().getWindow());
            try {
                FileOutputStream f_out = new FileOutputStream(f);
                byte[] b =c.getBytes();
                f_out.write(b);                                                                         
                f_out.close();
            } catch (FileNotFoundException ex) {} 
            catch (IOException ex) {}
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        pr1.visibleProperty().bind(s1.runningProperty());
        pr1.progressProperty().bind(s1.progressProperty());
        pr2.visibleProperty().bind(s2.runningProperty());
        pr2.progressProperty().bind(s2.progressProperty());
        pr3.visibleProperty().bind(h.runningProperty());
        pr3.progressProperty().bind(h.progressProperty());
        
        
        sensorID.setCellValueFactory((new PropertyValueFactory<>("SensorID")));
        time.setCellValueFactory(new PropertyValueFactory<>("Time"));
        value.setCellValueFactory(new PropertyValueFactory<>("Value"));
        unit.setCellValueFactory(new PropertyValueFactory<>("Unit"));
        description.setCellValueFactory(new PropertyValueFactory<>("Description"));
        
        sens1.pressedProperty().addListener(new ChangeListener<Boolean>(){
            @Override
            public void changed(ObservableValue<? extends Boolean> ov, Boolean t, Boolean t1) {
                if(t1){
                    if(!s1.isRunning()){
                        sens1.setText("Stop");
                        s1.reset();
                        s1.start();
                    }else{
                        sens1.setText("Start");
                        s1.cancel();
                    }
                }
            }     
        });
        
        sens2.pressedProperty().addListener(new ChangeListener<Boolean>(){
            @Override
            public void changed(ObservableValue<? extends Boolean> ov, Boolean t, Boolean t1) {
                if(t1){
                    if(!s2.isRunning()){
                        sens2.setText("Stop");
                        s2.reset();
                        s2.start();
                    }else{
                        sens2.setText("Start");
                        s2.cancel();
                    }
                }
            }
            
        });
        
        bothub.pressedProperty().addListener(new ChangeListener<Boolean>(){
            @Override
            public void changed(ObservableValue<? extends Boolean> ov, Boolean t, Boolean t1) {
                if(t1){
                    if(!h.isRunning()){
                        bothub.setText("Stop");
                        h.reset();
                        h.start();
                    }else{
                        bothub.setText("Start");
                        h.cancel();
                    }
                }
            }
            
        });
        
        h.valueProperty().addListener(new ChangeListener<sensorMeasure>(){
            @Override
            public void changed(ObservableValue<? extends sensorMeasure> ov, sensorMeasure t, sensorMeasure t1) {
                ObservableList<sensorMeasure> list = FXCollections.observableArrayList();
                
                list.add(t1);
                list.addAll(tab.getItems());
                
                tab.setItems(list);
                
            }
        
        });
        
        file.setInitialDirectory(file.getInitialDirectory());
        file.getExtensionFilters().addAll(
                new ExtensionFilter("Text Files","*.txt")
        );
        
    }    
    
}
