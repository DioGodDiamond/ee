/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CovidReport;

import java.time.LocalDateTime;

/**
 *
 * @author Giuseppe
 */
public class Detection extends Object{
    
// Definizione di una classe    
    private LocalDateTime data;

    private String stato;
    private int codice_regione;
    private String denominazione_regione;
    private String codice_provincia;
    private String denominazione_provincia;
    private String sigla_provincia;
    private double lati;
    private double longi;
    private int totale_casi;
    private String note;

    public LocalDateTime getData() {
        return data;
    }

    public void setData(LocalDateTime data) {
        this.data = data;
    }

    public String getStato() {
        return stato;
    }

    public void setStato(String stato) {
        this.stato = stato;
    }

    public int getCodice_regione() {
        return codice_regione;
    }

    public void setCodice_regione(int codice_regione) {
        this.codice_regione = codice_regione;
    }

    public String getDenominazione_regione() {
        return denominazione_regione;
    }

    public void setDenominazione_regione(String denominazione_regione) {
        this.denominazione_regione = denominazione_regione;
    }

    public String getCodice_provincia() {
        return codice_provincia;
    }

    public void setCodice_provincia(String codice_provincia) {
        this.codice_provincia = codice_provincia;
    }

    public String getDenominazione_provincia() {
        return denominazione_provincia;
    }

    public void setDenominazione_provincia(String denominazione_provincia) {
        this.denominazione_provincia = denominazione_provincia;
    }

    public String getSigla_provincia() {
        return sigla_provincia;
    }

    public void setSigla_provincia(String sigla_provincia) {
        this.sigla_provincia = sigla_provincia;
    }

    public double getLati() {
        return lati;
    }

    public void setLati(double lati) {
        this.lati = lati;
    }

    public double getLongi() {
        return longi;
    }

    public void setLongi(double longi) {
        this.longi = longi;
    }

    public int getTotale_casi() {
        return totale_casi;
    }

    public void setTotale_casi(int totale_casi) {
        this.totale_casi = totale_casi;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }


    public Detection(LocalDateTime data,String stato,int codice_regione,String denominazione_regione,String codice_provincia,String denominazione_provincia,String sigla_provincia,double lati,double longi,int totale_casi,String note) {
        this.data = data;
        this.stato = stato;
        this.codice_regione = codice_regione;
        this.denominazione_regione = denominazione_regione;
        this.codice_provincia = codice_provincia;
        this.denominazione_provincia = denominazione_provincia;
        this.sigla_provincia = sigla_provincia;
        this.lati = lati;
        this.longi = longi;
        this.totale_casi = totale_casi;
        this.note = note;
    }
    
     // Sovrascrittura del metodo toString
    @Override
    public String toString() {
        return  "data=" + data +
                ", stato='" + stato + '\'' +
                ", codice_regione=" + codice_regione +
                ", denominazione_regione='" + denominazione_regione + '\'' +
                ", codice_provincia='" + codice_provincia + '\'' +
                ", denominazione_provincia='" + denominazione_provincia + '\'' +
                ", sigla_provincia='" + sigla_provincia + '\'' +
                ", lati=" + lati +
                ", longi=" + longi +
                ", totale_casi=" + totale_casi +
                ", note='" + note + '\'' + '\n';
    }
    
    

}
