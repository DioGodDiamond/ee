/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CovidReport;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.TreeSet;
import javafx.concurrent.Service;
import javafx.concurrent.Task;

/**
 *
 * @author Giuseppe
 */
public class RegionLoader extends Service<String> {
    private LocalDate selDate;
    private TreeSet<String> regions;
    private String regionCB;
    @Override
    protected Task<String> createTask() {
        return new Task<String>(){
            @Override
            protected String call() throws Exception {

                    try {
                        // URL del file CSV online
                        URL url = new URL("https://raw.githubusercontent.com/pcm-dpc/COVID-19/master/dati-province/dpc-covid19-ita-province-"+selDate.toString().replace("-","")+".csv");
                        regions= new TreeSet<>();

                        // Apri un bufferedReader per leggere il file CSV
                        BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));

                        // Leggi il file riga per riga
                        String line;
                        reader.readLine();
                        while ((line = reader.readLine()) != null) {
                            String[] parts = line.split(",");
                            String nomeRegione = parts[3];
                            regions.add(nomeRegione);
                            
                            
                        }

                        // Chiudi il reader
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                      // Otteniamo l'ultimo elemento del TreeSet
                    String ultimoElemento = regions.last();

            // Rimuoviamo l'ultimo elemento
                    regions.remove(ultimoElemento);
                    regions.add("Tutte le regioni");
                    setRegions(regions);
                    
                    return regions.toString();
            }
    
        };  
        
    }
     void setRegions(TreeSet<String> regions) {
        this.regions=regions;
    }
     TreeSet<String> getRegions() {
        return this.regions ;
    }
    void setDate(LocalDate newValue) {
        this.selDate=newValue;
    }

    void setRegion(String newValue) {
        this.regionCB=newValue;
    }
}
