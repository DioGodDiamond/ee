/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CovidReport;

import java.net.URL;
import javafx.util.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author Gucci
 */
public class CovidReportController implements Initializable {
    
    CovReportService detectionService = new CovReportService();
    RegionLoader regionService = new RegionLoader();
    LocalDate newValueDate;
    String newValueRegion="Tutte le regioni";
    private boolean isProgrammaticChange = false;
    private Label label;
    @FXML
    private DatePicker datepicker;
    @FXML
    private ChoiceBox<String> choicebox;
    @FXML
    private ProgressBar progresbar;
    @FXML
    private TableView<Detection> tab;
    @FXML
    private TableColumn<Detection, String> c1;
    @FXML
    private TableColumn<Detection, String> c2;
    @FXML
    private TableColumn<Detection, Integer> c3;
    @FXML
    private Label loadinglbl;
    @FXML
    private Label undertablbl;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        undertablbl.setVisible(false);
        loadinglbl.setText(" ");
        c1.setText("Regione");
        c2.setText("Provincia");
        c3.setText("Casi Registrati");
        c1.setCellValueFactory(new PropertyValueFactory<>("denominazione_regione"));
        c2.setCellValueFactory(new PropertyValueFactory<>("denominazione_provincia"));
        c3.setCellValueFactory(new PropertyValueFactory<>("totale_casi"));
        detectionService.start();
        progresbar.setProgress(ProgressBar.INDETERMINATE_PROGRESS);       
        progresbar.setVisible(false);
        
        choicebox.setItems(FXCollections.observableArrayList("Tutte le regioni"));
        choicebox.setValue("Tutte le regioni");
        
        detectionService.setOnSucceeded(event -> {
            // Aggiornamento dell'interfaccia utente quando il servizio ha completato l'operazione
          tab.setItems(FXCollections.observableArrayList(detectionService.getValue()));
          progresbar.setVisible(false);
          loadinglbl.setText("Completato");
          //choicebox.setItems(FXCollections.observableArrayList(regioniService.getValue()));
        });
        regionService.setOnSucceeded(event -> {
            // Aggiornamento dell'interfaccia utente quando il servizio ha completato l'operazione
          ArrayList<String> regions = new ArrayList<>(regionService.getRegions());
          ObservableList<String> OALregions=FXCollections.observableArrayList(regions);
          isProgrammaticChange = true;
          choicebox.setItems(OALregions);
          choicebox.setValue(newValueRegion);
          isProgrammaticChange = false;
          
          //choicebox.setItems(FXCollections.observableArrayList(regioniService.getValue()));
        });
        
        datepicker.valueProperty().addListener(new ChangeListener<LocalDate>() {
            @Override
            public void changed(ObservableValue<? extends LocalDate> observable, LocalDate oldValue, LocalDate newValue) {
            progresbar.setVisible(true);
            loadinglbl.setText("Caricamento...");
        // Questo metodo verrà chiamato ogni volta che la data selezionata nel DatePicker cambia
            System.out.println("Data selezionata: " + newValue);
            undertablbl.setVisible(false);
        // Puoi inserire qui la logica per gestire la nuova data selezionata
            regionService.cancel();
            regionService.reset();
            regionService.setDate(newValue);
            regionService.start();
            detectionService.cancel();
            detectionService.reset();
            detectionService.setDate(newValue);
            newValueDate=newValue;
            detectionService.start();
            
            }

        });
        
         choicebox.valueProperty().addListener(new ChangeListener<String>() {

            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                if (!isProgrammaticChange) {// Questo metodo verrà chiamato ogni volta che la data selezionata nel DatePicker cambia
                    progresbar.setVisible(true);
                    loadinglbl.setText("Caricamento...");
                    System.out.println("Regione selezionata: " + newValue);
                    undertablbl.setVisible(false);
            // Puoi inserire qui la logica per gestire la nuova data selezionata
                    detectionService.cancel();
                    detectionService.reset();
                    detectionService.setRegion(newValue);
                    newValueRegion=newValue;
                    detectionService.start();
                    
            }
            }
            
        });
         tab.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                undertablbl.setVisible(true);
                undertablbl.setText("sigla provincia= "+newValue.getSigla_provincia()+", latitudine= "+ newValue.getLati()+", longitudine= "+ newValue.getLongi()+", note= "+ newValue.getNote());
                // Aggiornare le etichette con i dettagli della rilevazione selezionata
            }
        });
        
         //progresbar.visibleProperty().bind(detectionService.runningProperty());
    }
    
    
       
    
}
