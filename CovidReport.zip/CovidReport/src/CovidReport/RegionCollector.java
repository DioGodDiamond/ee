/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CovidReport;

import java.util.ArrayList;

/**
 *
 * @author Giuseppe
 */
public class RegionCollector {
    
    private String regionName;
    
    public RegionCollector(String regionName) {
        this.regionName = regionName;
    }
    
    public String getNome() {
        return regionName;
    }
    
    public static void main(String[] args) {
        ArrayList<RegionCollector> region = new ArrayList<>();  
    }
}
