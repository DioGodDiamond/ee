/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CovidReport;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

 /*
 * @author Giuseppe
 */
public class OnlineCSVParser {
    
    //xdomani ==> vedere su chatgpt per il parsing
    
}
