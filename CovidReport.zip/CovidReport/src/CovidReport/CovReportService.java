/*
passare da stringa a localdatetime
        String dataString = "2021-12-29T17:00:00";
        LocalDateTime dateTime = LocalDateTime.parse(dataString);
-----------------------------------------------------------------
passare da localdatetime a localdate
        LocalDateTime dateTime = LocalDateTime.now();
        LocalDate date = dateTime.toLocalDate();
 */
package CovidReport;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.TreeSet;
import javafx.concurrent.Service;
import javafx.concurrent.Task;

/**
 *
 * @author Giuseppe
 */
public class CovReportService extends Service<List<Detection>> {
    private LocalDate selDate;
    private LocalDateTime timeRequest;
    private TreeSet<String> regions;
    private String regionCB="Tutte le regioni";
    private String others;
        @Override
        protected Task<List<Detection>> createTask() {
            return new Task<List<Detection>>() {
                CovReportEntry entry = new CovReportEntry();
                int lineaCompromessa;
                @Override
                protected List<Detection> call() throws Exception {

                    try {
                        // URL del file CSV online
                        URL url = new URL("https://raw.githubusercontent.com/pcm-dpc/COVID-19/master/dati-province/dpc-covid19-ita-province-"+selDate.toString().replace("-","")+".csv");
                        
                        // Apri un bufferedReader per leggere il file CSV
                        BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));

                        // Leggi il file riga per riga
                        String line;
                        reader.readLine();
                        requestLog(url.toString(),timeRequest.now());
                        while ((line = reader.readLine()) != null) {
                            String[] parts = line.split(",");
                            String nomeRegione = parts[3];
                            lineaCompromessa=lineaCompromessa+1;
                            entry.addRegion(nomeRegione);
                            if (regionCB.equals("Tutte le regioni")){
                                if ((parts[0].isEmpty())||(parts[1].isEmpty())||(parts[2].isEmpty())||(parts[3].isEmpty())||(parts[4].isEmpty())||(parts[5].isEmpty())||(parts[6].isEmpty())||(parts[7].isEmpty())||(parts[8].isEmpty())||(parts[9].isEmpty())){
                                    scriviLog(lineaCompromessa);
                                    continue;
                            }
                                
                            }else if ((parts[0].isEmpty())||(parts[1].isEmpty())||(parts[2].isEmpty())||((!(parts[3].equals(regionCB)))||(parts[3].isEmpty()))||(parts[4].isEmpty())||(parts[5].isEmpty())||(parts[6].isEmpty())||(parts[7].isEmpty())||(parts[8].isEmpty())||(parts[9].isEmpty())){
                                    continue;
                                }
                               
                            entry.addDetection(LocalDateTime.parse(parts[0]),parts[1],Integer.parseInt(parts[2]),parts[3],parts[4],parts[5],parts[6],Double.parseDouble(parts[7]),Double.parseDouble(parts[8]),Integer.parseInt(parts[9]),parts[10]);                            
                           
                        }

                        // Chiudi il reader
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                      // Otteniamo l'ultimo elemento del TreeSet
                    String ultimoElemento = entry.getRegionsEntry().last();

            // Rimuoviamo l'ultimo elemento
                    entry.getRegionsEntry().remove(ultimoElemento);
                    entry.addRegion("Tutte le regioni");
                    setRegions(entry.getRegionsEntry());
                    return entry.getDetections();
                }
            };
        }
    void setRegions(TreeSet<String> regions) {
        this.regions=regions;
    }
     TreeSet<String> getRegions() {
        return this.regions ;
    }
     String bottomlblToString() {
        
        return this.others ;
    }
    void setDate(LocalDate newValue) {
        this.selDate=newValue;
    }

    void setRegion(String newValue) {
        this.regionCB=newValue;
    }
    public void requestLog(String url, LocalDateTime timestamp) {
        try (BufferedWriter fileLog = new BufferedWriter(new FileWriter("log.txt", true))) {
            fileLog.write("Log richiesta su " + url + " " + timestamp.toString() + "\n");
            fileLog.write("\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void scriviLog(int lineaCompromessa) {
        try (BufferedWriter fileLog = new BufferedWriter(new FileWriter("log.txt", true))) {
            fileLog.write("linea " + lineaCompromessa + " malformata o valori mancanti" +"\n");
            fileLog.write("\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
